# sentence = 'I love the idea that studying unlocks new levels of knowledge for me.'
# result = len(sentence.split())
# print("There are "+ str(result) +" words in the text")


def add(a,b):
    print (a+b)

add(6,9)
